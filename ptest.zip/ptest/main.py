import os
import sys
from string import (digits,
                    ascii_lowercase,
                    ascii_uppercase)

def contains_chars(word, chars):
    "Tells if this word contains a char from chars"
    for char in chars:
        if char in word:
            return True
    return False

def count(file_path):
    """
    Takes file path as input
    and returns count of following things :

    1) total number of blank lines - done
    2) total number of words - done
    3) total number of words with at-least one number - done
    4) total number of words without any special character - done
    5) total number of words each character is special character - done
    6) total number of words with only numbers - done
    7) total number of only two dots(..) (not ... or.) - done
    8) total number of word starting with capital letter - done
    9) Total number of word starting with small letter not contain vowel and not contain special char and contain number - done
    """
    with open(file_path, "r") as file:
        blank_lines = 0
        words_count = 0
        at_least_one_digit = 0
        isalnum_count = 0
        specialwords_count = 0
        onlydigit_count = 0
        twodots_count = 0
        capitalized_count = 0
        special_case_count = 0
        for line in file:
            if line.strip() == "":
                blank_lines += 1
            words = line.split()
            words_count += len(words)
            for word in words:
                if contains_chars(word, digits):
                    at_least_one_digit += 1
                if word.isalnum():
                    isalnum_count += 1
                if not contains_chars(word.lower(), digits + ascii_lowercase):
                    specialwords_count += 1
                if word.isdigit():
                    onlydigit_count += 1
                if word == "..":
                    twodots_count += 1
                if contains_chars(word[0], ascii_uppercase):
                    capitalized_count += 1
                # point 9 is little bit confusing.
                # a word that starts with lower case character, and does not contain any vowel
                # and does not contain any special character, and does contain number(s)
                # i.e. ghsgf74???
                if contains_chars(word, "bcdfghjklmnpqrtsvwxyz" + digits):
                    special_case_count += 1
    return (blank_lines,
            words_count,
            at_least_one_digit,
            isalnum_count,
            specialwords_count,
            onlydigit_count,
            twodots_count,
            capitalized_count,
            special_case_count)

if __name__ == "__main__":
    # Self test
    # program syntax : python main.py [-h] /path/to/folder file1_to_ignore, file2_to_ignore ... 
    if len(sys.argv) < 2 or "-h" in sys.argv:
        print("Usage:")
        print("python main.py /path/to/folder file1_to_ignore, file2_to_ignore ... ")
        sys.exit(0)
    folder_path = sys.argv[1] # get folder path
    if not os.path.isdir(folder_path): # make sure this folder does exist
        print("Invalid folder name. Please enter a valid folder path")
        sys.exit(0)
    
    ignore_list = sys.argv[2:]

    results =[]
    for root_dir, dir_list, file_names in os.walk(folder_path):
        for file_name in file_names:
            if file_name in ignore_list:
                continue
            file_path = os.path.join(root_dir, file_name)
            results.append(count(file_path))
    
    res = list(zip(*results))

    names = "blank_lines,words_count,at_least_one_digit,isalnum_count,specialwords_count,onlydigit_count,twodots_count,capitalized_count,special_case_count".split(",")
    for variable_name, value in zip(names, res):
        print("Total", variable_name, sum(value))
